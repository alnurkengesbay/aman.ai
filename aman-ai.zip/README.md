# Aman AI — Платформа нейродиагностики

<div align="center">
  <h3>🧠 AI-платформа для диагностики и реабилитации нейродегенеративных заболеваний</h3>
  <p>amanai.kz</p>
</div>

---

## 🎯 О платформе

Aman AI — это интеграционная платформа, объединяющая 6 AI-сервисов для комплексной диагностики и реабилитации нейродегенеративных заболеваний.

### Сервисы (микросервисы как iframe)

| Сервис | Описание | Команда |
|--------|----------|---------|
| **S1** CT/MRI | Deep Learning анализ снимков мозга | Murat, Adilet |
| **S2** IoT | PPG, IMU, EMG мониторинг (стресс, HRV, SpO2) | Mukhammedzhan |
| **S3** Опросники | AI-анализ опросников стресса | Mukhammedzhan |
| **S4** Генетика | AlphaFold, ESMFold анализ | Bekzat, Kaisar |
| **S5** Кровь | ML-анализ биомаркеров крови | Nursultan, Damir |
| **S6** Реабилитация | YOLO CV для нейрореабилитации | Murat, Adilet |

---

## 🏗️ Архитектура

```
┌─────────────────────────────────────────────────────────────────┐
│                        AMAN AI PLATFORM                          │
│                         (Next.js 14)                             │
├─────────────────────────────────────────────────────────────────┤
│  ┌─────────┐  ┌─────────┐  ┌─────────┐  ┌─────────┐  ┌────────┐│
│  │   S1    │  │   S2    │  │   S3    │  │   S4    │  │   S5   ││
│  │ CT/MRI  │  │   IoT   │  │Опросники│  │Генетика │  │  Кровь ││
│  └────┬────┘  └────┬────┘  └────┬────┘  └────┬────┘  └───┬────┘│
│       │           │            │            │            │      │
│       └───────────┴─────┬──────┴────────────┴────────────┘      │
│                         │                                        │
│                    ┌────┴────┐                                   │
│                    │ FastAPI │                                   │
│                    │ Backend │                                   │
│                    └────┬────┘                                   │
│                         │                                        │
│                    ┌────┴────┐                                   │
│                    │PostgreSQL│                                  │
│                    └─────────┘                                   │
└─────────────────────────────────────────────────────────────────┘
```

---

## 👥 Роли пользователей

### Пациент (PATIENT)
- Загрузка анализов и медицинских данных
- Прохождение опросников
- Просмотр AI-результатов
- Получение заключений от врачей

### Врач (DOCTOR)
- Просмотр пациентов
- Верификация AI-диагнозов
- Создание заключений и рекомендаций

### Администратор (ADMIN)
- Управление пользователями
- Настройка сервисов (URL iframe)
- Мониторинг системы

---

## 🚀 Запуск проекта

### Требования
- Node.js 18+
- Python 3.10+
- PostgreSQL 15+
- Docker (опционально)

### 1. Установка зависимостей

```bash
# Frontend
npm install

# Backend
cd backend
pip install -r requirements.txt
```

### 2. Настройка окружения

```bash
# Скопируйте .env.example в .env и заполните:
DATABASE_URL="postgresql://user:password@localhost:5432/amanai"
AUTH_SECRET="your-super-secret-key"
AUTH_URL="http://localhost:3000"
```

### 3. База данных

```bash
# Создание таблиц
npx prisma db push

# Или миграции
npx prisma migrate dev
```

### 4. Запуск

```bash
# Frontend (порт 3000)
npm run dev

# Backend (порт 8000)
cd backend
uvicorn app.main:app --reload --port 8000
```

---

## 📁 Структура проекта

```
aman/
├── src/
│   ├── app/
│   │   ├── (api)/            # API routes
│   │   ├── dashboard/        # Patient dashboard
│   │   ├── doctor/           # Doctor dashboard
│   │   ├── admin/            # Admin dashboard
│   │   ├── login/            # Auth pages
│   │   └── register/
│   ├── components/
│   │   ├── ui/               # Shadcn/ui components
│   │   └── ...               # App components
│   └── lib/
│       ├── auth.ts           # NextAuth config
│       ├── db.ts             # Prisma client
│       └── services.ts       # Services config
├── backend/
│   └── app/
│       ├── api/              # FastAPI endpoints
│       └── core/             # Config, settings
├── prisma/
│   └── schema.prisma         # Database schema
└── frontend/                 # Original v0 design (reference)
```

---

## 🎨 Дизайн-система

### Цвета (строго Ч/Б)

```css
/* Светлая тема */
--background: oklch(0.99 0 0);    /* Почти белый */
--foreground: oklch(0.1 0 0);     /* Почти чёрный */
--muted: oklch(0.96 0 0);         /* Серый фон */
--border: oklch(0.92 0 0);        /* Граница */

/* Тёмная тема */
--background: oklch(0.1 0 0);     /* Почти чёрный */
--foreground: oklch(0.98 0 0);    /* Почти белый */
```

### Типографика

```css
--font-sans: Manrope, system-ui;  /* Основной шрифт */
--font-mono: JetBrains Mono;      /* Код */
```

### Компоненты

- **Buttons**: `rounded-full` или `rounded-xl`
- **Cards**: `rounded-2xl` с тонкой границей
- **Inputs**: Минималистичные, с подчёркиванием

---

## 🔌 Интеграция сервисов (для команд S1-S6)

### Как подключить свой сервис

1. Разверните свой сервис как отдельный веб-сайт
2. Сообщите URL администратору платформы
3. Сервис будет встроен через iframe

### Требования к сервису

```typescript
// Ваш сервис должен:
// 1. Принимать userId через URL параметр
// 2. Возвращать результаты через POST на /api/results

// Пример URL вашего сервиса:
https://your-service.com/?userId=xxx&token=yyy

// Результаты отправлять на:
POST https://amanai.kz/api/services/results
{
  "userId": "xxx",
  "serviceType": "CT_MRI", // или IOT, QUESTIONNAIRE, etc.
  "result": { ... },
  "confidence": 0.95,
  "findings": ["Finding 1", "Finding 2"]
}
```

### Дизайн для iframe

Ваш сервис должен соответствовать дизайн-системе:
- Чёрно-белая цветовая схема
- Шрифт Manrope
- Минималистичный UI

---

## 📡 API Endpoints

### Frontend API (Next.js)

```
POST   /api/auth/register    # Регистрация
POST   /api/auth/[...nextauth] # NextAuth
```

### Backend API (FastAPI)

```
GET    /api/v1/health        # Health check
POST   /api/v1/auth/token    # JWT token

# Сервисы
POST   /api/v1/ct-mri/analyze
POST   /api/v1/iot/session
POST   /api/v1/questionnaire/submit
POST   /api/v1/genetics/analyze
POST   /api/v1/blood/analyze
POST   /api/v1/rehabilitation/session
```

---

## 📊 База данных (Prisma Schema)

### Основные модели

- `User` — пользователь (email, role)
- `Patient` — профиль пациента
- `Doctor` — профиль врача
- `Analysis` — результат AI-анализа
- `IotSession` — сессия IoT мониторинга
- `QuestionnaireResult` — результат опросника
- `HealthReport` — заключение врача

---

## 🛠️ Команды разработки

```bash
# Разработка
npm run dev                 # Next.js dev server
npm run build               # Production build
npm run lint                # Линтинг

# База данных
npx prisma studio           # GUI для БД
npx prisma db push          # Синхронизация схемы
npx prisma generate         # Генерация клиента

# Backend
uvicorn app.main:app --reload  # FastAPI dev
```

---

## 📄 Лицензия

MIT © 2024 Aman AI Team
